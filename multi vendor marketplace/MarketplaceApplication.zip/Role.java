package com.example.marketplace.model;

public enum Role {
    CUSTOMER,
    VENDOR,
    ADMIN
}
